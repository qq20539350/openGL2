#import <UIKit/UIKit.h>

//! Project version number for GPUImage.
FOUNDATION_EXPORT double GPUImageVersionNumber;

//! Project version string for GPUImage.
FOUNDATION_EXPORT const unsigned char GPUImageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GPUImage/PublicHeader.h>


