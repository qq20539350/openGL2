swiftc Source/main.swift -o SimpleVideoFilter -I ../../../framework -L ../../../framework -lGPUImage
