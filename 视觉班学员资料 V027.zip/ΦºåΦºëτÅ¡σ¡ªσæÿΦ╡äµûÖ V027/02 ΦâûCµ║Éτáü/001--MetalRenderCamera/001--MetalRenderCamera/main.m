//
//  main.m
//  001--MetalRenderCamera
//
//  Created by CC老师 on 2019/5/6.
//  Copyright © 2019年 CC老师. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
